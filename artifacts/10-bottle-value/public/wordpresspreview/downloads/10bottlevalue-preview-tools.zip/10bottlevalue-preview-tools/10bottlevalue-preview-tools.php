<?php
/**
 * Plugin Name: 10BottleValue Preview Tools — STAGING ONLY
 * Description: Explicit public-catalog import and verification for a disposable review store. Disables payments, orders and outgoing email.
 * Version: 0.1.1
 * Requires PHP: 8.1
 * Requires Plugins: woocommerce
 */
defined('ABSPATH') || exit;

function tbv_review_require_empty_store() {
    if (!class_exists('WooCommerce') || !function_exists('wc_get_orders')) {
        throw new RuntimeException('Activate WooCommerce first. This plugin is for an empty staging review store only.');
    }
    $statuses = array_unique(array_merge(array_keys(wc_get_order_statuses()), ['trash', 'checkout-draft']));
    if (wc_get_orders(['limit' => 1, 'return' => 'ids', 'status' => $statuses])) {
        throw new RuntimeException('Refusing preview tools: this store already contains an order. Use a separate empty staging installation.');
    }
}

register_activation_hook(__FILE__, function ($network_wide) {
    try {
        if ($network_wide) throw new RuntimeException('Activate per staging site, not across a network.');
        tbv_review_require_empty_store();
    } catch (Throwable $error) {
        wp_die(esc_html($error->getMessage()), 'Preview activation refused', ['back_link' => true]);
    }
});

// On activation WordPress has already fired plugins_loaded; these filters start
// only after the activation checks pass and the plugin is active next request.
add_action('plugins_loaded', function () {
    if (!defined('TBV_MIGRATION_PREVIEW')) require __DIR__ . '/tbv-preview-isolation.php';
}, PHP_INT_MAX);

add_action('admin_menu', function () {
    add_management_page('10BottleValue Preview', '10BottleValue Preview', 'manage_woocommerce', 'tbv-review', 'tbv_review_page');
});

function tbv_review_page() {
    if (!current_user_can('manage_woocommerce')) wp_die('Access denied.', '', ['response' => 403]);
    echo '<div class="wrap"><h1>10BottleValue — staging review only</h1>';
    echo '<p>Payments, real checkout orders and outgoing email are disabled while preview isolation is active. No provider keys are included.</p>';
    echo '<p>The dated public snapshot contains 66 products / 166 offers. Historical customers, orders, credits, referrals and fulfillment are not migrated. Existing preview pages and matching preview SKUs are updated by import; no automatic import runs.</p>';
    echo '<p>Import requires the active 10bottlevalue theme, WooCommerce and zero orders. Use a disposable empty staging store; retain a backup before import. Verification also exercises and clears the current staging cart.</p>';
    foreach (['import' => 'Import / refresh public demo catalog', 'verify' => 'Verify imported snapshot'] as $action => $label) {
        echo '<form method="post" action="' . esc_url(admin_url('admin-post.php')) . '">';
        echo '<input type="hidden" name="action" value="tbv_review_' . esc_attr($action) . '">';
        wp_nonce_field('tbv_review_' . $action);
        echo '<p><label><input type="checkbox" name="review_confirm" value="1" required> I am using a disposable staging review store.</label></p>';
        submit_button($label, $action === 'import' ? 'primary' : 'secondary');
        echo '</form>';
    }
    echo '</div>';
}

function tbv_review_run($action) {
    if (($_SERVER['REQUEST_METHOD'] ?? '') !== 'POST' || !current_user_can('manage_woocommerce')) {
        wp_die('Access denied.', '', ['response' => 403]);
    }
    check_admin_referer('tbv_review_' . $action);
    if (($_POST['review_confirm'] ?? '') !== '1') wp_die('Confirm the staging review store.', '', ['response' => 400]);
    $buffer_level = ob_get_level();
    try {
        tbv_review_require_empty_store();
        if (get_template() !== '10bottlevalue' || !defined('TBV_MIGRATION_PREVIEW') || TBV_MIGRATION_PREVIEW !== true) {
            throw new RuntimeException('Activate the supplied 10bottlevalue theme and preview isolation first.');
        }
        if (function_exists('tbv_preview_image_id') || function_exists('tbv_verify')) {
            throw new RuntimeException('A preview script has already run in this request. Reload the Tools page.');
        }
        // admin-post.php omits WooCommerce's storefront helpers. Verification
        // exercises notices and cart persistence, so load the supported frontend
        // includes after every staging/security check and before creating a cart.
        if ($action === 'verify' && (!function_exists('wc_clear_notices') || !function_exists('wc_get_cart_item_data_hash'))) {
            WC()->frontend_includes();
        }
        define('TBV_REVIEW_ADMIN_ACTION', true);
        global $checks, $failures;
        ob_start();
        require __DIR__ . ($action === 'import' ? '/bootstrap-preview.php' : '/verify-preview.php');
        $report = ob_get_clean();
    } catch (Throwable $error) {
        while (ob_get_level() > $buffer_level) ob_end_clean();
        wp_die(esc_html($error->getMessage()), 'Preview action failed', ['response' => 400, 'back_link' => true]);
        return;
    }
    wp_die('<h1>Preview ' . esc_html($action) . ' result</h1><pre>' . esc_html($report) . '</pre>', 'Preview result', ['response' => 200, 'back_link' => true]);
}

add_action('admin_post_tbv_review_import', function () { tbv_review_run('import'); });
add_action('admin_post_tbv_review_verify', function () { tbv_review_run('verify'); });
