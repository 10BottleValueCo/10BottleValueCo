10BottleValue Preview Tools — STAGING / REVIEW ONLY
Prepared 2026-10-24. Version 0.1.1. Not a production cutover.

Install
1. Start a separate empty, disposable WordPress staging installation. Retain a
   backup first. Do not install this preview plugin on the operating store.
2. Install/activate WooCommerce and the supplied 10bottlevalue theme ZIP.
3. Upload 10bottlevalue-preview-tools.zip through Plugins > Add New > Upload.
4. Activate. Activation refuses a store containing ANY WooCommerce order and
   refuses activation without WooCommerce. Network activation is unsupported.
5. Open Tools > 10BottleValue Preview. An administrator with manage_woocommerce
   must confirm the staging checkbox and explicitly click Import. No catalog
   import or reimport runs automatically on activation or a normal page request.
6. Click Verify to inspect the imported public snapshot and native cart checks.
   Version 0.1.1 loads WooCommerce's supported frontend helpers for this guarded
   admin action, so notice clearing and cart-session persistence work in admin-post.
   Verification exercises and clears the current staging cart; no order is made.
   The JSON result appears on screen and is saved in the local WordPress option
   tbv_review_verification_report. Retain it with the staging review receipt.

Boundaries
While active, preview isolation blocks outgoing mail, payment gateways, classic
checkout order submission, Store API checkout writes and pay-for-order actions.
No processor credentials, payment code, customer data, historical orders, store
credits, referral balances, supplier data or production fulfillment are included.
No shipping/tax configuration is invented. Historical data remains UNMIGRATED.
Import updates the plugin's matching preview SKUs and standard preview pages;
it does not delete unrelated products. Restore the staging backup to undo the
full import. Deactivation/removal does not delete the imported catalog or pages.
Never treat disabling this plugin as a production-launch procedure.

Source and provenance
Catalog: migration/public-catalog.json from source commit
5672c65ca153ec565256cd1d805f8a4a34fdb718, extracted 2026-10-22.
166 offers / 66 names: 120 Worldwide, 46 US, 144 source in-stock booleans.
This is a dated source snapshot, not a live stock count or supplier confirmation.
The theme provides the matching original vial assets and the explicit placeholder
for the known US Tesamorelin source-image mismatch. Stock quantities are unknown.
Stable offer SKUs, dosage, pack size, warehouse, formulation, prior aliases and
certificate associations are retained by the importer.

Implementation: plugin entry plus copies of migration/bootstrap-preview.php,
verify-preview.php, tbv-preview-isolation.php and public-catalog.json. Packaged
bootstrap/verify helpers reject direct access and require the nonce/capability
protected admin action. The verifier stores its report in a WordPress option
instead of requiring a writable plugin directory. The internal isolation file
has no standalone plugin header; existing preview MU isolation is not duplicated.
The copied bootstrap records Elite 10 Management Group LLC only as an undecided
owner-considered proposal. No business formation or payment account is implied.

Call requirement verified 2026-10-24
The available Oct 17 Buddima call transcript requests a WordPress replica and an
installable theme ZIP plus plugin ZIP at 50:44–51:19. WooCommerce was not named.
At 52:09 a future custom transaction/status webhook is discussed, but no API
contract, credentials or signature scheme was supplied. This preview implements
no concealed-product or processor-review evasion flow, no live payment provider,
and no signed-contract or settlement claim.

Runtime evidence
Read the adjacent plugin-validation.json for checks actually performed. A valid
ZIP and PHP syntax/security harness are not proof of hosting, visual 1:1 parity,
production checkout, a migrated customer database or provider acceptance.

РУССКИЙ
Только отдельный пустой тестовый WordPress, WooCommerce и тема 10bottlevalue.
Плагин запрещает активацию при наличии заказов и без WooCommerce. Импорт запускает
только пользователь с manage_woocommerce кнопкой в Tools > 10BottleValue Preview,
после подтверждения тестовой среды; проверяются POST и nonce. Автоимпорта нет.
Проверка использует и очищает текущую тестовую корзину, но не создаёт заказ.
Платежи, создание заказов через checkout и исходящая почта заблокированы.
166 предложений / 66 названий — снимок исходников от 22 октября, а не живые
остатки. Клиенты, история заказов, кредиты, рефералы и фулфилмент НЕ ПЕРЕНЕСЕНЫ.
Импорт обновляет свои SKU и стандартные страницы; для полного отката восстановите
резервную копию тестового сайта. Удаление плагина не удаляет каталог/страницы.
ZIP не подтверждает хостинг, визуальное соответствие 1:1 или рабочую оплату.
Упомянутый Elite 10 Management Group LLC — неподтверждённый вариант названия.
Звонок проверен по доступной расшифровке: WordPress и два ZIP в 50:44–51:19;
будущий webhook в 52:09 без спецификации API/подписи. Платёжная интеграция здесь
не реализована; сокрытие реальных товаров от процессора исключено.

RU: Версия 0.1.1 загружает поддерживаемые frontend-функции WooCommerce только
после проверок защищённого действия Verify в admin-post: очистка уведомлений и
сохранение сессии корзины получают необходимые функции. Защитные проверки не
сняты, автоматический импорт не добавлен.
